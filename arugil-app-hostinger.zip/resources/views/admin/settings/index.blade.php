@extends('admin.layout')

@section('content')
<div class="header">
    <div>
        <h2>Settings</h2>
        <p class="muted">Platform configuration placeholders.</p>
    </div>
</div>

<div class="card">
    <p>Settings coming soon.</p>
</div>
@endsection
