@extends('admin.layout')

@section('content')
<div class="header">
    <div>
        <h2>Reports</h2>
        <p class="muted">System reports and analytics placeholders.</p>
    </div>
</div>

<div class="card">
    <p>No reports configured yet.</p>
</div>
@endsection
